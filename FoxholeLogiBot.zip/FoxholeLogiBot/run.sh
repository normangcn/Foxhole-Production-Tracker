#!/bin/bash
java -Ddata.file.path=./data.json -jar Foxhole_Production_Tracker.jar

